/*
This class contain no data and methods at all and are used as placeholder for derived classes for specific games.
*/
package TicTacToe;

public abstract class Move {
}

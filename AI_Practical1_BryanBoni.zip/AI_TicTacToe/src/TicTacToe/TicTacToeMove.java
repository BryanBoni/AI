package TicTacToe;
/*
this class simply consists of a single integer value to record
the square index for the new move.
*/
public class TicTacToeMove extends Move {

    protected int moveIndex;

    public TicTacToeMove() {

    }
}
